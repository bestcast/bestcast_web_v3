@extends('layouts.frontend')

@section('header-script')
<link rel="stylesheet" href="{{ asset('css/video.css') }}">
<script src="{{ asset('js/auth/logout.js') }}" defer></script>
<script src="{{ asset('js/video.js') }}" defer></script>
<script src="{{ asset('js/movies.js') }}" defer></script>
@endsection

@section('content') 

  <div class="ajxProfile"></div>

  <?php /*

  <div class="prfModal"><div class="in">
  		<div class="cntr"><div class="in">

  			<div class="view">
	  			<div class="title">Who's watching?</div>
		  		<div class="icList cfix">
		  			<div class="item">
		  				<div class="thumb" style="background-image:url(http://moviesdev.com/img/sample/profile-1.jpg);">
		  					<div class="in"></div>
		  				</div>
		  				<div class="label">Anu Kesavan</div>
		  				<div class="lock"></div>
		  			</div>
		  			<div class="item">
		  				<div class="thumb" style="background-image:url(http://moviesdev.com/img/sample/profile-1.jpg);">
		  					<div class="in"></div>
		  				</div>
		  				<div class="label">Anu Kesavan</div>
		  				<div class="lock"></div>
		  			</div>
		  			<div class="item">
		  				<div class="thumb" style="background-image:url(http://moviesdev.com/img/sample/profile-1.jpg);">
		  					<div class="in edit"></div>
		  				</div>
		  				<div class="label">Anu Kesavan</div>
		  				<div class="lock active"></div>
		  			</div>
		  		</div>
		  		<div class="action">
		  			<a class="btn">Manage Profiles</a>
		  			<a class="btn">Add New</a>
		  		</div>
	  		</div>


  			<div class="selecticon dnn"><!--.cntr .in add class .lengthy, html add class .noscroll-->
  				<div class="action fixed"><a class="btn">Back</a><a class="btn active">Continue</a></div>
	  			<div class="title">Choose a profile icon.</div>
		  		<div class="icList stack cfix">
		  			@for($i=0;$i<=9;$i++)
		  			<div class="item">
		  				<div class="thumb" style="background-image:url(http://moviesdev.com/img/sample/profile-1.jpg);">
		  					<div class="in active"></div>
		  				</div>
		  			</div>
		  			@endfor
		  		</div>
	  		</div>

  			<div class="addnew dnn">
	  			<div class="title">Add New Profile</div>
		  		<div class="icList form cfix">
		  			<div class="item left">
		  				<div class="thumb" style="background-image:url(http://moviesdev.com/img/sample/profile-1.jpg);">
		  					<div class="in edit"></div>
		  				</div>
		  			</div>
		  			<div class="right">
		  				<div class="lineBox"><input type="text" name="name" placeholder="Name" class="input-field"></div>
		  				<div class="lineBox">
		  					<div class="set">
	                            <input type="checkbox" id="is_child" name="is_child">
	                            <label for="is_child">Is Child?</label>
                        	</div>
		  					<div class="set">
	                            <input type="checkbox" id="autoplay" checked="checked" name="autoplay">
	                            <label for="autoplay">Autoplay on all devices?</label>
                        	</div>
		  				</div>
		  				<div class="lineBox">
		  					<div class="label">Set PIN</div>
		  					<input type="text" name="pin" max="4" placeholder="eg: 5111" class="input-field">
		  				</div>
		  			</div>
		  		</div>
		  		<div class="action">
		  			<a class="btn active">Save</a>
		  			<a class="btn">Cancel</a>
		  		</div>
	  		</div>

  			<div class="editnew dnn">
	  			<div class="title">Edit Profile</div>
		  		<div class="icList form cfix">
		  			<div class="item left">
		  				<div class="thumb" style="background-image:url(http://moviesdev.com/img/sample/profile-1.jpg);">
		  					<div class="in edit"></div>
		  				</div>
		  			</div>
		  			<div class="right">
		  				<div class="lineBox"><input type="text" name="name" placeholder="Name" class="input-field"></div>
		  				<div class="lineBox">
		  					<div class="set">
	                            <input type="checkbox" id="is_child_edit" name="is_child">
	                            <label for="is_child_edit">Is Child?</label>
                        	</div>
		  					<div class="set">
	                            <input type="checkbox" id="autoplay_edit" checked="checked" name="autoplay">
	                            <label for="autoplay_edit">Autoplay on all devices?</label>
                        	</div>
		  				</div>
		  				<div class="lineBox">
		  					<div class="label">Old PIN</div>
		  					<input type="text" name="pin" max="4" placeholder="eg: 5111" class="input-field">
		  				</div>
		  				<div class="lineBox">
		  					<div class="label">New PIN</div>
		  					<input type="text" name="pin" max="4" placeholder="eg: 5111" class="input-field">
		  				</div>
		  				<div class="lineBox">
		  					<div class="label">Forgot PIN?</div>
		  					<a class="btn active tiny">Send PIN to Email</a>
		  				</div>
		  			</div>
		  		</div>
		  		<div class="action">
		  			<a class="btn active">Save</a>
		  			<a class="btn">Cancel</a>
		  			<a class="btn">Delete Profile</a>
		  		</div>
	  		</div>


  		</div></div>
  </div></div>

  */ ?>

  <div class="previewMovie"></div>
  @include('movies.playermini')
  @include('movies.player')



  <?php /*
  <script type="text/javascript">
	document.addEventListener("DOMContentLoaded", function(event) { 				
		var settings = {
        loopingOn:true,
        showPosterOnPause: true,
        rememberPlaybackPosition: false,
        media:[                    
            {
                type: "hls",
                path:'https://d2vkl8k9v6nxyr.cloudfront.net/Movies/Testing/Encoded/1080/trailer%201080p.m3u8',
                poster:'http://moviesdev.com/img/sample/banner-bg.jpg',
            }         
        ]                            
		};

       var wrapper = document.getElementById("bannervideo");
       var videoPlayerText = document.getElementById("videoPlayerText");
       wrapper.innerHTML=videoPlayerText.innerHTML;
       player = new vpl(wrapper, settings);

    });
  </script>
  
	<div class="ajxBanner">
		<div class="bnCtr">
			<div class="bnPost muteBtn">
				<div id="bannervideo" style="background:url(http://moviesdev.com/img/sample/banner-bg.jpg)"></div>
				<div class="certificate">U/A 13+</div>
				<div class="bannerBox">
					<div class="bannerLogo"><img src="http://moviesdev.com/img/sample/banner-logo.png" /></div>
					<div class="bannerContent">
						<p>After going their separate ways years ago, three skilled martial artists reunite when a common enemy pursues a vendetta against them.</p>
					</div>
					<div class="bannerAction">
						<div class="playBtn">Play</div> <div class="moreInfo">More Info</div>
					</div>
				</div>
			</div>
			<div class="blended"></div>
		</div>
	</div>
	*/?>

  @include('movies.genre')
  <div class="ajxBanner"></div>

   <div class="container-fluid blkCtr">
      <div class="row">
         <div class="col-lg-12">
	         	<div class="ajxBlocks">
		         	<?php
		         	/*
			            <!-- <div class="carousel-slide edu-slick-button slick-activation-wrapper clearfix">
			                  <div class="edu-event event-grid-1 bg-shade">
			                     <div class="inner">
			                        <div class="thumbnail">
			                           <img src="http://moviesdev.com/img/placeholder/skeleton.png" alt="Loading">
			                        </div>
			                     </div>
			                  </div>
			            </div> -->
			            <!-- <div class="carousel-slide edu-slick-button slick-activation-wrapper clearfix">
			                  <div class="edu-event event-grid-1 bg-shade">
			                     <div class="inner">
			                        <div class="thumbnail">
			                           <img data-lazy="http://moviesdev.com/img/sample/banner-thumbnail.jpg" src="http://moviesdev.com/img/placeholder/skeleton.png" alt="Event Images">
			                           <div class="tagging top-position status-group left-top">
			                              <span class="recentTag">Recently Added</span>
			                           </div>
			                           <div class="tagging top-position right-top">
			                              <span class="top10Tag">Top 10</span>
			                           </div>
			                        </div>
			                     </div>
			                  </div>
			            </div> -->
		         	@for($j=0;$j<=5;$j++)
			         	<div class="slideList">
				            <div class="section-title">
				               <h4 class="title">Let’s Join Our Community</h4>
				            </div>
				            <div class="carousel-slide edu-slick-button slick-activation-wrapper clearfix">
				            	@for($i=0;$i<=30;$i++)
				                  <div class="edu-event event-grid-1 bg-shade">
				                     <div class="inner">
				                        <div class="thumbnail">
				                           <img data-lazy="http://moviesdev.com/img/sample/banner-thumbnail.jpg" src="http://moviesdev.com/img/placeholder/skeleton.png" alt="Event Images">
				                           <div class="tagging top-position status-group left-top">
				                              <span class="recentTag">Recently Added</span>
				                           </div>
				                           <div class="tagging top-position right-top">
				                              <span class="top10Tag">Top 10</span>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				                @endfor
				            </div>
			        	</div>
		        	@endfor
		        	*/ ?>
	        	</div>
	        	<div class="loadingMore"></div>
         </div>
      </div>
   </div>


@endsection
