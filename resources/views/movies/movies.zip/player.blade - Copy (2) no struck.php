<div class="bigPlayerOuter dnn"><div class="vpl-player-loader dnnshow"></div>
   <div id="bigPlayerText" class="dnn">
      <div id="bigPlayer" class="vpl-skin-vega theatermode">
         <div class="vpl-player-holder">
            <div class="vpl-media-holder"></div>
            <div class="vpl-subtitle-holder">
               <div class="vpl-subtitle-holder-inner"></div>
            </div>
            <div class="vpl-player-controls vpl-player-controls-main">
            </div>
            <div class="vpl-share-holder"></div>
            <div class="vpl-info-holder">
               <div class="vpl-info-holder-inner">
                  <div class="vpl-info-data">
                     <button type="button" class="vpl-info-close vpl-contr-btn vpl-btn-reset" data-tooltip="Close">
                        <svg viewBox="0 0 320 512">
                           <path d="M207.6 256l107.72-107.72c6.23-6.23 6.23-16.34 0-22.58l-25.03-25.03c-6.23-6.23-16.34-6.23-22.58 0L160 208.4 52.28 100.68c-6.23-6.23-16.34-6.23-22.58 0L4.68 125.7c-6.23 6.23-6.23 16.34 0 22.58L112.4 256 4.68 363.72c-6.23 6.23-6.23 16.34 0 22.58l25.03 25.03c6.23 6.23 16.34 6.23 22.58 0L160 303.6l107.72 107.72c6.23 6.23 16.34 6.23 22.58 0l25.03-25.03c6.23-6.23 6.23-16.34 0-22.58L207.6 256z"></path>
                        </svg>
                     </button>
                     <div class="vpl-info-inner">
                        <div class="vpl-info-description"></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="vpl-resume-holder">
               <div class="vpl-resume-holder-inner">
                  <div class="vpl-resume-data">
                     <div class="vpl-resume-inner">
                        <button type="button" class="vpl-resume-action-container vpl-resume-continue vpl-btn-reset">
                           <span class="vpl-contr-btn">
                              <svg role="img" viewBox="0 0 373.008 373.008">
                                 <path d="M61.792,2.588C64.771,0.864,68.105,0,71.444,0c3.33,0,6.663,0.864,9.655,2.588l230.116,167.2 c5.963,3.445,9.656,9.823,9.656,16.719c0,6.895-3.683,13.272-9.656,16.713L81.099,370.427c-5.972,3.441-13.334,3.441-19.302,0 c-5.973-3.453-9.66-9.833-9.66-16.724V19.305C52.137,12.413,55.818,6.036,61.792,2.588z"></path>
                              </svg>
                           </span>
                           <span class="vpl-resume-title">Continue watching</span>
                        </button>
                        <div class="vpl-resume-action-container-separator"></div>
                        <button type="button" class="vpl-resume-action-container vpl-resume-restart vpl-btn-reset">
                           <span class="vpl-contr-btn">
                              <svg role="img" viewBox="0 0 512 512">
                                 <path d="M255.545 8c-66.269.119-126.438 26.233-170.86 68.685L48.971 40.971C33.851 25.851 8 36.559 8 57.941V192c0 13.255 10.745 24 24 24h134.059c21.382 0 32.09-25.851 16.971-40.971l-41.75-41.75c30.864-28.899 70.801-44.907 113.23-45.273 92.398-.798 170.283 73.977 169.484 169.442C423.236 348.009 349.816 424 256 424c-41.127 0-79.997-14.678-110.63-41.556-4.743-4.161-11.906-3.908-16.368.553L89.34 422.659c-4.872 4.872-4.631 12.815.482 17.433C133.798 479.813 192.074 504 256 504c136.966 0 247.999-111.033 248-247.998C504.001 119.193 392.354 7.755 255.545 8z"></path>
                              </svg>
                           </span>
                           <span class="vpl-resume-title">Restart from beginning</span>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
            <div class="vpl-context-menu">
               <div class="mvp-context-menu-inner">
                  <button type="button" class="vpl-context-btn vpl-context-copy-video-url vpl-btn-reset">
                  <span>Copy video url at current time</span>
                  </button>
               </div>
            </div>
            <div class="vpl-preview-seek-wrap">
               <div class="vpl-preview-seek-inner"></div>
               <div class="vpl-preview-seek-time">
                  <div class="vpl-preview-seek-time-current">0:00</div>
               </div>
            </div>
         </div>
         <div class="vpl-tooltip"></div>
         <div class="vpl-player-controls">
            <div class="vpl-back ICineLeft"></div>
         </div>
      </div>
   </div>
</div>
